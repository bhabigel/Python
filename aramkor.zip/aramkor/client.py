import json
import sys

filename = sys.argv[1]

with open(filename, "r") as readFile:
    data = json.load(readFile)

linkCapacities = {}
for link in data['links']:
    x, y = link['points']
    capacity = link['capacity']
    linkCapacities[(x, y)] = capacity
    linkCapacities[(y, x)] = capacity

demands = data['simulation']['demands']
simulationDuration = data['simulation']['duration']
count = 0
currentDemands = {}

def findRoute(start, end):
    for circuit in data['possible-circuits']:
        if circuit[0] == start and circuit[-1] == end:
            return circuit
    return None

def allocateResources(startTime, endTime, node1, node2, demand):
    route = findRoute(node1, node2)
    if not route:
        return False

    for i in range(len(route) - 1):
        if linkCapacities.get((route[i], route[i + 1]), 0) < demand:
            return False

    for i in range(len(route) - 1):
        linkCapacities[(route[i], route[i + 1])] -= demand
        linkCapacities[(route[i + 1], route[i])] -= demand

    currentDemands[(node1, node2)] = (startTime, endTime, demand, route)
    return True


def deallocateResources(node1, node2):
    if (node1, node2) in currentDemands:
        demandDetails = currentDemands[(node1, node2)]
        demand = demandDetails[2]
        route = demandDetails[3]
        routeLenght = len(route)
        for i in range(routeLenght - 1):
            firstLink = (route[i], route[i + 1])
            reverseLink = (route[i + 1], route[i])
            linkCapacities[firstLink] += demand
            linkCapacities[reverseLink] += demand
        del currentDemands[(node1, node2)]


for currentTime in range(1, simulationDuration + 1):
    for demand in sorted(demands, key=lambda x: x['start-time']):
        startTime = demand['start-time']
        endTime = demand['end-time']
        node1, node2 = demand['end-points']
        demandValue = demand['demand']
        if startTime == currentTime:
            count += 1
            success = allocateResources(startTime, endTime, node1, node2, demandValue)
            eventName = "igény foglalás"
            if success:
                print(f"{count}. {eventName}: {node1}<->{node2} st:{currentTime} – sikeres")
            else:
                print(f"{count}. {eventName}: {node1}<->{node2} st:{currentTime} – sikertelen")

    current = list(currentDemands.items())
    for demandPair in current:
        nodePair = demandPair[0]
        startTime = demandPair[1][0]
        endTime = demandPair[1][1]
        demandValue = demandPair[1][2]
        route = demandPair[1][3]
        if currentTime == endTime:
            count += 1
            deallocateResources(node1, node2)
            print(f"{count}. igény felszabadítás: {node1}<->{node2} st:{currentTime}")

