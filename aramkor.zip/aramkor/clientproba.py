import json
import sys

with open("cs1.json", "r") as read_file:
        data = json.load(read_file)

# Dictionary to store the capacities of links
link_capacities = {(link['points'][0], link['points'][1]): link['capacity'] for link in data['links']}

# Store demands and simulation duration
demands = data['simulation']['demands']
simulation_duration = data['simulation']['duration']
allocations = {}
event_count = 0

def find_route(start, end):
    """Find a valid route from start to end based on possible circuits."""
    for circuit in data['possible-circuits']:
        if circuit[0] == start and circuit[-1] == end:
            return circuit
    return None

def allocate_resources(start_time, end_time, node1, node2, demand):
    """Attempt to allocate resources between node1 and node2."""
    route = find_route(node1, node2)
    if not route:
        return False  # No valid route

    total_capacity = sum(link_capacities.get((route[i], route[i + 1]), 0) for i in range(len(route) - 1))

    if demand <= total_capacity:
        allocations[(node1, node2)] = (start_time, end_time, demand)
        return True
    return False

def deallocate_resources(node1, node2):
    """Deallocate resources between node1 and node2."""
    if (node1, node2) in allocations:
        del allocations[(node1, node2)]

# Main simulation process
current_time = 0

for demand in sorted(demands, key=lambda x: x['start-time']):
    start_time = demand['start-time']
    end_time = demand['end-time']
    node1, node2 = demand['end-points']
    demand_value = demand['demand']

    # Update the current simulation time
    current_time = start_time
    event_count += 1

    # Attempt to allocate resources
    success = allocate_resources(start_time, end_time, node1, node2, demand_value)
    event_name = "demand allocation"
    if success:
        print(f"{event_count}. {event_name}: {node1}<->{node2} st:{current_time} – successful")
    else:
        print(f"{event_count}. {event_name}: {node1}<->{node2} st:{current_time} – unsuccessful")

    # Simulate the deallocation process
    for time in range(start_time, end_time + 1):
        if time > start_time:
            current_time = time
            event_count += 1
            deallocate_resources(node1, node2)
            print(f"{event_count}. demand deallocation: {node1}<->{node2} st:{current_time}")
