import sys
import socket
import struct

serverAddr = sys.argv[1]
serverPort = int(sys.argv[2])

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout(2)
sock.connect((serverAddr, serverPort))

packer = struct.Struct("cI")

low = 1
high = 100
gameOver = False

while not gameOver and low <= high:
    guess = (low + high) // 2
    msg = packer.pack(b'<' if guess < (low + high) // 2 else '>', guess)

    sock.sendall(msg)

    try:
        response = sock.recv(packer.size)
        if response:
            respChar, _ = packer.unpack(response)
            respChar = respChar.decode('utf-8')

            if respChar == 'I':
                high = guess - 1
            elif respChar == 'N':
                low = guess + 1
            elif respChar == 'Y':
                gameOver = True
            elif respChar == 'K':
                gameOver = True
            elif respChar == 'V':
                gameOver = True
    except socket.timeout:
        break
    except ConnectionResetError:
        break

sock.close()
