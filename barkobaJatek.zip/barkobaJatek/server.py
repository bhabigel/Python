import sys
import socket
import random
import struct
import select

serverAddr = sys.argv[1]
serverPort = int(sys.argv[2])

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((serverAddr, serverPort))
server.listen(5)

numberToGuess = random.randint(1, 100)
packer = struct.Struct("cI")

inputs = [server]
clientsData = {}
gameOver = False

while inputs:
    readable, _, exceptional = select.select(inputs, [], inputs)

    for s in readable:
        if s is server:
            connection, clientInfo = server.accept()
            inputs.append(connection)
            clientsData[connection] = {'address': clientInfo}
        else:
            msg = s.recv(packer.size)
            if msg:
                guessType, guessNumber = packer.unpack(msg)
                guessType = guessType.decode('utf-8')

                if gameOver:
                    s.sendall(packer.pack(b'V', 0))
                    s.close()
                    inputs.remove(s)
                else:
                    if guessType == '<':
                        response = b'I' if guessNumber < numberToGuess else b'N'
                    elif guessType == '>':
                        response = b'I' if guessNumber > numberToGuess else b'N'
                    elif guessType == '=':
                        if guessNumber == numberToGuess:
                            response = b'Y'
                            gameOver = True
                        else:
                            response = b'K'

                    s.sendall(packer.pack(response, 0))

                    if response in [b'Y', b'K']:
                        s.close()
                        inputs.remove(s)
                        del clientsData[s]
            else:
                s.close()
                inputs.remove(s)
                del clientsData[s]

    for s in exceptional:
        inputs.remove(s)
        s.close()
        del clientsData[s]
