import sys
import struct

file_names = sys.argv[1:5]

#elso feladat
formats = ['f?c', 'c9si', 'i?f', 'cf9s']
for (file_name, file_data_format) in zip(file_names, formats):
    try:
        with open(file_name, 'rb') as file:
            unpacker = struct.Struct(file_data_format)
            data = file.read(unpacker.size)
            print(unpacker.unpack(data))
    except FileNotFoundError:
        print(f'{file_name} not found.', file=sys.stderr)

#masodik feladat
print(struct.pack('12s i ?', b'elso', 70, True))
print(struct.pack('f ? c', 73.5, False, b'X'))
print(struct.pack('i 10s f', 61, b'masodik', 80.9))
print(struct.pack('c i 13s', b'Z', 92, b'harmadik'))
