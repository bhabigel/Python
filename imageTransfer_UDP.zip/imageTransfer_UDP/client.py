import sys
import socket

server_addr = sys.argv[1]
server_port = int(sys.argv[2])
filePath = sys.argv[3]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

with open(filePath, 'rb') as f:
    while True:
        chunk = f.read(200)
        if not chunk:
            sock.sendto(b"", (server_addr, server_port))
            break
        sock.sendto(chunk, (server_addr, server_port))
        answer, _ = sock.recvfrom(1024)
        print("Kapott válasz:", answer.decode())
sock.close()
