import sys
import socket

server_addr = sys.argv[1]
server_port = int(sys.argv[2])
outputFile = "newImage.jpg"

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((server_addr, server_port))

with open(outputFile,'wb') as f:
    while True:
        try:
            data,client_addr = sock.recvfrom(1024)
            if not data:
                print("Megerkezett a teljes file")
                break
            print(f"{client_addr} : {len(data)} byte érkezett.")
            f.write(data)

            sock.sendto(b"OK", client_addr)
        except KeyboardInterrupt:
                break

sock.close()
print("Server terminated")