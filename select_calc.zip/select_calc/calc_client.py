# -*- coding: utf-8 -*-
import sys
import socket
import random
import struct
import time
import json

server_addr = sys.argv[1]
server_port = 65432 if len(sys.argv) < 3 else int(sys.argv[2])

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((server_addr, server_port))

ops = ["+", "-", "*", "/"]
packer = struct.Struct("i i 1s")

for nrnd in range(5):
    operand_a = random.randint(1, 100)
    operand_b = random.randint(1, 100)
    operator = random.choice(ops)

    format_type = random.choice(["JSON", "STRC"])

    if format_type == "JSON":
        sock.sendall(b"JSON")
        data = {
            "operand_a": operand_a,
            "operand_b": operand_b,
            "operator": operator
        }
        msg = json.dumps(data)
        print(f"Message (JSON): {msg}")
        sock.sendall(msg.encode())
    else:
        sock.sendall(b"STRC")
        msg = packer.pack(operand_a, operand_b, operator.encode())
        print(f"Message (Struct): {operand_a} {operator} {operand_b}")
        sock.sendall(msg)

    if format_type == "JSON":
        msg = sock.recv(1024).decode()
        response = json.loads(msg)
        print(f"Received result (JSON): {response['result']}")
    else:
        msg = sock.recv(packer.size)
        result, _, _ = packer.unpack(msg)
        print(f"Received result (Struct): {result}")

    time.sleep(1)

sock.close()
